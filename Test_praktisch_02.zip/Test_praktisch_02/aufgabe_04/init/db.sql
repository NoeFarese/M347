DROP TABLE IF EXISTS `Movies`;

CREATE TABLE `Movies` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`title` varchar(255) DEFAULT NULL,
	`year` int(11) DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
LOCK TABLES `Movies` WRITE;
INSERT INTO `Movies` (`title`, `year`) VALUES
('Spider-Man: Far From Home', 2019),
('Top Gun : Maverik', 2022),
('Avengers: Endgame', 2019),
('Avengers: Infinity War', 2018),
('Captain America: The First Avenger', 2011),
('Captain America: The Winter Soldier', 2014),
('Captain America: Civil War', 2016);
UNLOCK TABLES;
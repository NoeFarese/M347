<!DOCTYPE html>
<html lang="de">
<head>
	  <title> Telefon Liste PHP </title>
</head>

<body bgcolor="yellow">
<h1>Telefonnummer Suche</h1>


<!-- Eingebeddeter PHP Code -->
<?php
if(!isset($_GET['surname']))
{
	$currentName= "";
}
else
{
	$currentName = $_GET['surname'];
}

if($currentName != "")
{
	if(checkName($currentName))
	{
		echo "Der Name ". $currentName . " wurde gefunden";
		//echo file_get_contents('http://localhost:8080/');
	}
	else
	{
		echo "Unbekannter Name: ". $currentName;
	}
}

function checkName($userName)
{
	$userList = array( 	"Markus" =>		"041 225 65 85", 
						"Heidi" =>		"041 874 56 35", 
						"Philipp" => 	"041 987 25 65", 
						"Paul" => 		"041 665 33 25",
						"Susi" =>		"041 958 65 24"
					);
	
	if (array_key_exists($userName, $userList))
	{
		echo "<p>Name: $userName, Tel: $userList[$userName]</p>";
		return true;
	}
	return false;
}
?>

<!-- Formular Bereich -->
<form action="index.php" method="get">
 
<p>Geben Sie einen Namen ein:
<input type="text" name="surname">
</p>
 
<p>
<input type="submit" value="Suchen">
</p>
 
</form>

</body>
